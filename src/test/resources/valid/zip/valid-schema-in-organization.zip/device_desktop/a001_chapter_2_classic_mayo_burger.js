DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"shape74":{"x":-1,"y":603,"w":1010.000000,"h":60.000000,"stylemods":[{"sel":"div.shape74Text","decl":" { position:fixed; left:3px; top:3px; width:1004px; height:54px;}"},{"sel":"span.shape74Text","decl":" { display:table-cell; position:relative; width:1004px; height:54px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/IAAAA8CAYAAADFaIFhAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAECSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHKgBs0kAAcnEJv4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 1009.000000 1.000000 L 1009.000000 59.000000 L 1.000000 59.000000 L 1.000000 1.000000 z" ,"i":"images/shape74.png"}
,
"image60":{"x":0,"y":0,"w":1011,"h":149,"bOffBottom":0,"i":"images/rr160_operationdeclutter_redops_redspace_header_fa.jpg"}
,
"button38368":{"x":763,"y":614,"w":139.000000,"h":33.000000,"stylemods":[{"sel":"div.button38368Text","decl":" { position:fixed; left:4px; top:3px; width:131px; height:27px;}"},{"sel":"span.button38368Text","decl":" { display:table-cell; position:relative; width:131px; height:27px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAAAhCAYAAADpnlh3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMXSURBVHhe7ZaBbeMwDEW7z63SUTpIBsmcyfExnwIlx7LSS5oewAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRFscrlcvlzvV5PdjXMdrbrU5LQYP+S6aU8Y76U4yxT8S9YIz9pqHGiuTK3A2R33yyN/7fD8kUOIJ/MxXdRL08a7vKMzXuEZ8yn+DN347DGYgIbQRfZGJl2yZvHs12+Cdwl6UCHP7Bx+0kLyGOu7ufP8E2Vz+dzsYEPm4ZTmE/xngfkauQ5eLZrtyazxRfYISbb7T5+lTd5QquhY7bDPsnFVz7m+vmfVSZdndh00XQ2rL2lN1P/1jLGSAxju0eRXSNkYw2bw4pN/t1NmWFSmuu1kUOx3fzkwm5MawrdGB/I1w41OmxArMzRlzzPQ32yW9fnH4UFcGk4xXR7b0uXI+nGjemKtfH0q5by+Fsfz3IfkvURb3TNTnmPapoeVLQ5N8+6iGl9yGNyjX4Yc4F0S/v0MljA6iJMd3fDKCznwC9d11h02DU8nJt45eGwPPRWEaPY8a3ubDzLdlST68Ceu80F4vFpGJv7SQ579HVHDu4aL/UJGBvL9b8EiuHScApFsWKKlMmhiJyDMbo9JDucO81Hw735ch0SMfcwX1t/mmNaE6DFhh4Yy5XzcED8WXY/6OMzmGSpTyDT2w/L9Kcgg0bab31ZRojJcSPEx3zMsZITUtzmcMme17pUU4a8xIBMjkzE+XqxhdbuftDwudiQbqkmdMbbD4s3a2Uhoc0FA7FmO9yAEfzS3W3WmMfu/la7c4JJNp/xYJxznCMw0+5hgTEPRIyudlDR4eNP1vMs27RPgM5472EBCmMldqfIsRh/U9J4qbFopJ3+dBAn3ebAYJOvzafx7ibCGJOJnEa8+Us14ber1YIv+wE/ucCeu0Mk22bdZlvqExrj/YcFKI7F3NZ0g+IoRpLQHDY2MFv8g9chd8NM3bzG7kaS0xU7jQs/sTJtMF/7QqGT/rAmbGgBH7FyOSnXeIjiQHRzBGY/7JNMv+OwFEVRFEVRFEVRFEVRFEXxCB8ffwGvgEH15eyJmAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAAAhCAYAAADpnlh3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMXSURBVHhe7ZaBbeMwDEW7z63SUTpIBsmcyfExnwIlx7LSS5oewAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRFscrlcvlzvV5PdjXMdrbrU5LQYP+S6aU8Y76U4yxT8S9YIz9pqHGiuTK3A2R33yyN/7fD8kUOIJ/MxXdRL08a7vKMzXuEZ8yn+DN347DGYgIbQRfZGJl2yZvHs12+Cdwl6UCHP7Bx+0kLyGOu7ufP8E2Vz+dzsYEPm4ZTmE/xngfkauQ5eLZrtyazxRfYISbb7T5+lTd5QquhY7bDPsnFVz7m+vmfVSZdndh00XQ2rL2lN1P/1jLGSAxju0eRXSNkYw2bw4pN/t1NmWFSmuu1kUOx3fzkwm5MawrdGB/I1w41OmxArMzRlzzPQ32yW9fnH4UFcGk4xXR7b0uXI+nGjemKtfH0q5by+Fsfz3IfkvURb3TNTnmPapoeVLQ5N8+6iGl9yGNyjX4Yc4F0S/v0MljA6iJMd3fDKCznwC9d11h02DU8nJt45eGwPPRWEaPY8a3ubDzLdlST68Ceu80F4vFpGJv7SQ579HVHDu4aL/UJGBvL9b8EiuHScApFsWKKlMmhiJyDMbo9JDucO81Hw735ch0SMfcwX1t/mmNaE6DFhh4Yy5XzcED8WXY/6OMzmGSpTyDT2w/L9Kcgg0bab31ZRojJcSPEx3zMsZITUtzmcMme17pUU4a8xIBMjkzE+XqxhdbuftDwudiQbqkmdMbbD4s3a2Uhoc0FA7FmO9yAEfzS3W3WmMfu/la7c4JJNp/xYJxznCMw0+5hgTEPRIyudlDR4eNP1vMs27RPgM5472EBCmMldqfIsRh/U9J4qbFopJ3+dBAn3ebAYJOvzafx7ibCGJOJnEa8+Us14ber1YIv+wE/ucCeu0Mk22bdZlvqExrj/YcFKI7F3NZ0g+IoRpLQHDY2MFv8g9chd8NM3bzG7kaS0xU7jQs/sTJtMF/7QqGT/rAmbGgBH7FyOSnXeIjiQHRzBGY/7JNMv+OwFEVRFEVRFEVRFEVRFEXxCB8ffwGvgEH15eyJmAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAAiCAYAAACN1jGgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMZSURBVHhe7ZaBbeMwDEW7z62SUTpIBumczfExnwIlx5ZyTS4pwAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRF8Sy+v7//XC6Xs10Ns33ZdZIkNNg/ZXoqj5gv5fiSqfgp1swTTTXONFjmdojs7hum8W87MJ/kAPLJXPwE9fOs4S6P2MB7eMR8iv/ibkxrLCawGXSSzZFpl7yBPNvlG8Fdkg50+AMbt5+3gDzm6n4KDd9Y+Xw+Fxv4sGl4CPMp3vOAXI08B8927dZktvgSO8Rku93Hr/MmT2g1dMw27ZNcfO1jrtf8xDLx6uSmi8azae1tvZr6t5cxRmIY2z0K7ZohG2vYHFhs8u9uzBEmpcFeGzkU281PLuzGYU2hG+MD+drBRocNiJU5+pLnuatPduv6/N9hEVwaHmK6vbemy5F04+Z0Bdv48OuW8vjbH89yT8n6iDe6hqe8s5oODyvanJtnXcS0PuQxuUY/jLlAuqV9eiosYnUhpru5aRSXc+CXrmsuOuwaTucmXnk4MHe9XcQodny7OxvPss1qch3Yc7fBQDw+DWODT+SwR1935OCu8VKfgLGxXP/ToCAuDQ+hMFZNoTI5FJJzMEa3h2TTudN8NN03QK4pEXML87X1pzkOawK02NADY7lyHg6JP8vuh318BpMs9QlkeosDc/izkEEj7T99YUaIyXEjxMd8zLGSE1Lc5oDJnte6VFOGvMSATI5MxPl6sYXW7n7Y8LnYkG6pJnTGWxwYb9jKYkKbiwZizTbdhBH80t1s2JjH7v52u/MAk2w+6cE45zhHYKbdAwNjHogYXe2wosPHn6znWbbDPgE64/UHBiiO1didQseC/I1J46XmopH28GeEOOk2hwabfG0+jXc3EsaYTOQ04guwVBN+u1ot+LIf8JML7Lk7SLJt1m22pT6hMd7jwAAFsqDruq5QIAVJEpppcwOzxT99HXI3zNTNa+xuJjldsdO88BMr0wbztS8VOumnNWFDC/iIlctJucaDFIeimyMw+7RPMr3PgSmKoiiKoiiKoiiKoiiKoiheysfHXxBUQfWvUXBZAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAAAhCAYAAADpnlh3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMXSURBVHhe7ZaBbeMwDEW7z63SUTpIBsmcyfExnwIlx7LSS5oewAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRFscrlcvlzvV5PdjXMdrbrU5LQYP+S6aU8Y76U4yxT8S9YIz9pqHGiuTK3A2R33yyN/7fD8kUOIJ/MxXdRL08a7vKMzXuEZ8yn+DN347DGYgIbQRfZGJl2yZvHs12+Cdwl6UCHP7Bx+0kLyGOu7ufP8E2Vz+dzsYEPm4ZTmE/xngfkauQ5eLZrtyazxRfYISbb7T5+lTd5QquhY7bDPsnFVz7m+vmfVSZdndh00XQ2rL2lN1P/1jLGSAxju0eRXSNkYw2bw4pN/t1NmWFSmuu1kUOx3fzkwm5MawrdGB/I1w41OmxArMzRlzzPQ32yW9fnH4UFcGk4xXR7b0uXI+nGjemKtfH0q5by+Fsfz3IfkvURb3TNTnmPapoeVLQ5N8+6iGl9yGNyjX4Yc4F0S/v0MljA6iJMd3fDKCznwC9d11h02DU8nJt45eGwPPRWEaPY8a3ubDzLdlST68Ceu80F4vFpGJv7SQ579HVHDu4aL/UJGBvL9b8EiuHScApFsWKKlMmhiJyDMbo9JDucO81Hw735ch0SMfcwX1t/mmNaE6DFhh4Yy5XzcED8WXY/6OMzmGSpTyDT2w/L9Kcgg0bab31ZRojJcSPEx3zMsZITUtzmcMme17pUU4a8xIBMjkzE+XqxhdbuftDwudiQbqkmdMbbD4s3a2Uhoc0FA7FmO9yAEfzS3W3WmMfu/la7c4JJNp/xYJxznCMw0+5hgTEPRIyudlDR4eNP1vMs27RPgM5472EBCmMldqfIsRh/U9J4qbFopJ3+dBAn3ebAYJOvzafx7ibCGJOJnEa8+Us14ber1YIv+wE/ucCeu0Mk22bdZlvqExrj/YcFKI7F3NZ0g+IoRpLQHDY2MFv8g9chd8NM3bzG7kaS0xU7jQs/sTJtMF/7QqGT/rAmbGgBH7FyOSnXeIjiQHRzBGY/7JNMv+OwFEVRFEVRFEVRFEVRFEXxCB8ffwGvgEH15eyJmAAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 8.000000 1.000000 L 131.000000 1.000000 L 133.750000 1.562500 L 135.937500 3.062500 L 137.437500 5.312500 L 138.000000 8.000000 L 138.000000 25.000000 L 137.437500 27.750000 L 135.937500 29.937500 L 133.750000 31.437500 L 131.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","i":"images/button38368.png","irol":"images/button38368_over.png","ion":"images/button38368_down.png","idis":"images/button38368_disabled.png"}
,
"button38362":{"x":919,"y":614,"w":67.000000,"h":33.000000,"stylemods":[{"sel":"div.button38362Text","decl":" { position:fixed; left:4px; top:3px; width:59px; height:27px;}"},{"sel":"span.button38362Text","decl":" { display:table-cell; position:relative; width:59px; height:27px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAAhCAYAAACC9hYiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFQSURBVGhD7ZVRcsIwDERzn16Fo3AQDsI5A3pC8siOw/SnTWj3zWRsrdaOLAwsQgghhBBCCPHprOv69TBsvIfUYanbXu7Pkc0Am19Dbpj84814vf1xi/A4ajOAOFKOSf+vGTZevaShKOJZM4rfsfgSKSfzo25S28/G7oMIjmtKFkTRFJLzSE+bUXx+i2LtrCF39Ajru8bbB6e6GX4QL8vwpGHTrhmjP8GDN8IG3tTx2DP7XWqeQxkPx+ilRXGMHII5cBiSrAvJwYceYSP3Y4+6T4W8cb5mAIWlxrweInN7hK2D9eTqOyq+8KzNAC/vxbduxh7F/5k3A4i9RKMeovg33/2R4r3k3Ngcek//dWrBITVMy+vdfaIWT/82R/AY7ZD4EcZ17M8T4XFYEe+akblNofjRyVciTSM2f8mAjo+9Q/L3lL2OvyFCCCGEEOIdy/IElTLCsgl11f4AAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAAhCAYAAACC9hYiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFQSURBVGhD7ZVRcsIwDERzn16Fo3AQDsI5A3pC8siOw/SnTWj3zWRsrdaOLAwsQgghhBBCCPHprOv69TBsvIfUYanbXu7Pkc0Am19Dbpj84814vf1xi/A4ajOAOFKOSf+vGTZevaShKOJZM4rfsfgSKSfzo25S28/G7oMIjmtKFkTRFJLzSE+bUXx+i2LtrCF39Ajru8bbB6e6GX4QL8vwpGHTrhmjP8GDN8IG3tTx2DP7XWqeQxkPx+ilRXGMHII5cBiSrAvJwYceYSP3Y4+6T4W8cb5mAIWlxrweInN7hK2D9eTqOyq+8KzNAC/vxbduxh7F/5k3A4i9RKMeovg33/2R4r3k3Ngcek//dWrBITVMy+vdfaIWT/82R/AY7ZD4EcZ17M8T4XFYEe+akblNofjRyVciTSM2f8mAjo+9Q/L3lL2OvyFCCCGEEOIdy/IElTLCsgl11f4AAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAAAiCAYAAADmvn/1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFRSURBVGhD7ZXRbcMwDES9T1bJKBkkg2ROp3wMKVCyXOSjhd3mHmBIPJ5kihaSRQghhBBCCCE+jXVdL0/DxkdIHZa67+X+JdkQsPkt5IbJv96Q19uf9wiPpTYEiCPlmPSZDbHx5mUNhRHPGlL8jsXXSDmZH3WT2n42dh8jOLYxWRSFU0zOIz1tSPH5bYq1s6Y80COs7xpvIZzuhvhhvDTDk4ZNu4aM/gQP3ggbeFPHY8/sd6p5Dmc8IKOXFwUychDmwIFIsi4kBx96hI3cjz3qPhXyxjkbAhSXGvN6kMztEbYO1pOr76j4wjM3BLzEF2/dkD2K/+/eECD2Mo16kOLf/BaMFO8158bm4Hv6IdSiQ2qYlle9+7IWT/9SR/AY7aD4EcZ17M8T4bFYId81JHObYvGjk69EmmZs/q4BHR97h+TvKXud46YIIYQQQgjxwyzLF56FwrL1Ff2NAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAAhCAYAAACC9hYiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFQSURBVGhD7ZVRcsIwDERzn16Fo3AQDsI5A3pC8siOw/SnTWj3zWRsrdaOLAwsQgghhBBCCPHprOv69TBsvIfUYanbXu7Pkc0Am19Dbpj84814vf1xi/A4ajOAOFKOSf+vGTZevaShKOJZM4rfsfgSKSfzo25S28/G7oMIjmtKFkTRFJLzSE+bUXx+i2LtrCF39Ajru8bbB6e6GX4QL8vwpGHTrhmjP8GDN8IG3tTx2DP7XWqeQxkPx+ilRXGMHII5cBiSrAvJwYceYSP3Y4+6T4W8cb5mAIWlxrweInN7hK2D9eTqOyq+8KzNAC/vxbduxh7F/5k3A4i9RKMeovg33/2R4r3k3Ngcek//dWrBITVMy+vdfaIWT/82R/AY7ZD4EcZ17M8T4XFYEe+akblNofjRyVciTSM2f8mAjo+9Q/L3lL2OvyFCCCGEEOIdy/IElTLCsgl11f4AAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 8.000000 1.000000 L 59.000000 1.000000 L 61.750000 1.562500 L 63.937500 3.062500 L 65.437500 5.312500 L 66.000000 8.000000 L 66.000000 25.000000 L 65.437500 27.750000 L 63.937500 29.937500 L 61.750000 31.437500 L 59.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","i":"images/button38362.png","irol":"images/button38362_over.png","ion":"images/button38362_down.png","idis":"images/button38362_disabled.png"}
,
"image77":{"x":1041,"y":245,"w":300,"h":175,"bOffBottom":0,"i":"images/rotatephone-300x175.png"}
,
"text75":{"x":1232,"y":486,"w":200,"h":80,"txtscale":100,"bOffBottom":0}
,
"text38392":{"x":24,"y":157,"w":729,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38390":{"x":646,"y":132,"w":263,"h":486,"bOffBottom":0,"i":"images/classic_mayo_burger_question.jpg"}
,
"text38393":{"x":456,"y":314,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38394":{"x":430,"y":206,"w":223,"h":91,"bOffBottom":0,"i":"images/mayo_72dpi_webready_small.png"}
,
"text38396":{"x":240,"y":563,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38397":{"x":221,"y":465,"w":213,"h":88,"bOffBottom":0,"i":"images/lettuce_72dpi_webready_small.png"}
,
"text38399":{"x":240,"y":435,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38400":{"x":215,"y":348,"w":225,"h":85,"bOffBottom":0,"i":"images/buttermilkpatty_small.png"}
,
"text38402":{"x":1032,"y":503,"w":48,"h":19,"txtscale":100,"bOffBottom":0}
,
"image38403":{"x":424,"y":224,"w":223,"h":91,"bOffBottom":0,"i":"images/mayo_72dpi_webready_small.png"}
,
"text38405":{"x":456,"y":563,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38406":{"x":441,"y":463,"w":188,"h":88,"bOffBottom":0,"i":"images/tomato_slice_72dpi_webready_small.png"}
,
"text38408":{"x":456,"y":435,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38409":{"x":432,"y":358,"w":207,"h":58,"bOffBottom":0,"i":"images/shredded_chicken_72dpi_webready_small.png"}
,
"text38411":{"x":22,"y":563,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38412":{"x":2,"y":458,"w":217,"h":111,"bOffBottom":0,"i":"images/cheese_slice_72dpi_webready_small.png"}
,
"text38414":{"x":240,"y":314,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38415":{"x":215,"y":222,"w":224,"h":91,"bOffBottom":0,"i":"images/classic_herb_mayo_sauce_circle_72dpi_webready.png"}
,
"text38417":{"x":22,"y":435,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38418":{"x":15,"y":355,"w":191,"h":71,"bOffBottom":0,"i":"images/crispy_bacon_slice_72dpi_webready.png"}
,
"text38964":{"x":22,"y":314,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image38965":{"x":-1,"y":223,"w":223,"h":91,"bOffBottom":0,"i":"images/chilli_aioli_circle.png"}
,
"image38377":{"x":923,"y":524,"w":70,"h":70,"bOffBottom":0,"i":"images/check.png"}
,
"image38374":{"x":929,"y":530,"w":58,"h":58,"bOffBottom":0,"i":"images/cross_3.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
dragMgr.addDrop( 669, 266, 217, 59, '1', Update_qu38387 );
dragMgr.addDrop( 667, 330, 222, 59, '2', Update_qu38387 );
dragMgr.addDrop( 669, 397, 219, 59, '3', Update_qu38387 );
dragMgr.addDrop( 669, 459, 219, 59, '4', Update_qu38387 );

Init_qu38387(false, true);
}
,
"RCDResultResize":function(){}
,"preload":['images/rr160_operationdeclutter_redops_redspace_header_fa.jpg','images/rotatephone-300x175.png','images/check.png','images/cross_3.png','images/cheese_slice_72dpi_webready_small.png','images/buttermilkpatty_small.png','images/lettuce_72dpi_webready_small.png','images/tomato_slice_72dpi_webready_small.png','images/shredded_chicken_72dpi_webready_small.png','images/mayo_72dpi_webready_small.png','images/classic_herb_mayo_sauce_circle_72dpi_webready.png','images/crispy_bacon_slice_72dpi_webready.png','images/classic_mayo_burger_question.jpg','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/button38368.png','images/button38368_over.png','images/button38368_down.png','images/button38368_disabled.png','images/button38362.png','images/button38362_over.png','images/button38362_down.png','images/button38362_disabled.png']
}}
