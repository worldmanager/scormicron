DesktopResponsive={"1009":{
"pageLayer":{"w":1009,"h":662,"bgColor":"#ffffff"}
,
"shape74":{"x":-1,"y":603,"w":1010.000000,"h":60.000000,"stylemods":[{"sel":"div.shape74Text","decl":" { position:fixed; left:3px; top:3px; width:1004px; height:54px;}"},{"sel":"span.shape74Text","decl":" { display:table-cell; position:relative; width:1004px; height:54px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA/IAAAA8CAYAAADFaIFhAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAECSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHKgBs0kAAcnEJv4AAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 1009.000000 1.000000 L 1009.000000 59.000000 L 1.000000 59.000000 L 1.000000 1.000000 z" ,"i":"images/shape74.png"}
,
"image60":{"x":0,"y":0,"w":1011,"h":149,"bOffBottom":0,"i":"images/rr160_operationdeclutter_redops_redspace_header_fa.jpg"}
,
"text40073":{"x":23,"y":157,"w":651,"h":48,"txtscale":100,"bOffBottom":0}
,
"button40037":{"x":763,"y":614,"w":139.000000,"h":33.000000,"stylemods":[{"sel":"div.button40037Text","decl":" { position:fixed; left:4px; top:3px; width:131px; height:27px;}"},{"sel":"span.button40037Text","decl":" { display:table-cell; position:relative; width:131px; height:27px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAAAhCAYAAADpnlh3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMXSURBVHhe7ZaBbeMwDEW7z63SUTpIBsmcyfExnwIlx7LSS5oewAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRFscrlcvlzvV5PdjXMdrbrU5LQYP+S6aU8Y76U4yxT8S9YIz9pqHGiuTK3A2R33yyN/7fD8kUOIJ/MxXdRL08a7vKMzXuEZ8yn+DN347DGYgIbQRfZGJl2yZvHs12+Cdwl6UCHP7Bx+0kLyGOu7ufP8E2Vz+dzsYEPm4ZTmE/xngfkauQ5eLZrtyazxRfYISbb7T5+lTd5QquhY7bDPsnFVz7m+vmfVSZdndh00XQ2rL2lN1P/1jLGSAxju0eRXSNkYw2bw4pN/t1NmWFSmuu1kUOx3fzkwm5MawrdGB/I1w41OmxArMzRlzzPQ32yW9fnH4UFcGk4xXR7b0uXI+nGjemKtfH0q5by+Fsfz3IfkvURb3TNTnmPapoeVLQ5N8+6iGl9yGNyjX4Yc4F0S/v0MljA6iJMd3fDKCznwC9d11h02DU8nJt45eGwPPRWEaPY8a3ubDzLdlST68Ceu80F4vFpGJv7SQ579HVHDu4aL/UJGBvL9b8EiuHScApFsWKKlMmhiJyDMbo9JDucO81Hw735ch0SMfcwX1t/mmNaE6DFhh4Yy5XzcED8WXY/6OMzmGSpTyDT2w/L9Kcgg0bab31ZRojJcSPEx3zMsZITUtzmcMme17pUU4a8xIBMjkzE+XqxhdbuftDwudiQbqkmdMbbD4s3a2Uhoc0FA7FmO9yAEfzS3W3WmMfu/la7c4JJNp/xYJxznCMw0+5hgTEPRIyudlDR4eNP1vMs27RPgM5472EBCmMldqfIsRh/U9J4qbFopJ3+dBAn3ebAYJOvzafx7ibCGJOJnEa8+Us14ber1YIv+wE/ucCeu0Mk22bdZlvqExrj/YcFKI7F3NZ0g+IoRpLQHDY2MFv8g9chd8NM3bzG7kaS0xU7jQs/sTJtMF/7QqGT/rAmbGgBH7FyOSnXeIjiQHRzBGY/7JNMv+OwFEVRFEVRFEVRFEVRFEXxCB8ffwGvgEH15eyJmAAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAAAhCAYAAADpnlh3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMXSURBVHhe7ZaBbeMwDEW7z63SUTpIBsmcyfExnwIlx7LSS5oewAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRFscrlcvlzvV5PdjXMdrbrU5LQYP+S6aU8Y76U4yxT8S9YIz9pqHGiuTK3A2R33yyN/7fD8kUOIJ/MxXdRL08a7vKMzXuEZ8yn+DN347DGYgIbQRfZGJl2yZvHs12+Cdwl6UCHP7Bx+0kLyGOu7ufP8E2Vz+dzsYEPm4ZTmE/xngfkauQ5eLZrtyazxRfYISbb7T5+lTd5QquhY7bDPsnFVz7m+vmfVSZdndh00XQ2rL2lN1P/1jLGSAxju0eRXSNkYw2bw4pN/t1NmWFSmuu1kUOx3fzkwm5MawrdGB/I1w41OmxArMzRlzzPQ32yW9fnH4UFcGk4xXR7b0uXI+nGjemKtfH0q5by+Fsfz3IfkvURb3TNTnmPapoeVLQ5N8+6iGl9yGNyjX4Yc4F0S/v0MljA6iJMd3fDKCznwC9d11h02DU8nJt45eGwPPRWEaPY8a3ubDzLdlST68Ceu80F4vFpGJv7SQ579HVHDu4aL/UJGBvL9b8EiuHScApFsWKKlMmhiJyDMbo9JDucO81Hw735ch0SMfcwX1t/mmNaE6DFhh4Yy5XzcED8WXY/6OMzmGSpTyDT2w/L9Kcgg0bab31ZRojJcSPEx3zMsZITUtzmcMme17pUU4a8xIBMjkzE+XqxhdbuftDwudiQbqkmdMbbD4s3a2Uhoc0FA7FmO9yAEfzS3W3WmMfu/la7c4JJNp/xYJxznCMw0+5hgTEPRIyudlDR4eNP1vMs27RPgM5472EBCmMldqfIsRh/U9J4qbFopJ3+dBAn3ebAYJOvzafx7ibCGJOJnEa8+Us14ber1YIv+wE/ucCeu0Mk22bdZlvqExrj/YcFKI7F3NZ0g+IoRpLQHDY2MFv8g9chd8NM3bzG7kaS0xU7jQs/sTJtMF/7QqGT/rAmbGgBH7FyOSnXeIjiQHRzBGY/7JNMv+OwFEVRFEVRFEVRFEVRFEXxCB8ffwGvgEH15eyJmAAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIwAAAAiCAYAAACN1jGgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMZSURBVHhe7ZaBbeMwDEW7z62SUTpIBumczfExnwIlx5ZyTS4pwAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRF8Sy+v7//XC6Xs10Ns33ZdZIkNNg/ZXoqj5gv5fiSqfgp1swTTTXONFjmdojs7hum8W87MJ/kAPLJXPwE9fOs4S6P2MB7eMR8iv/ibkxrLCawGXSSzZFpl7yBPNvlG8Fdkg50+AMbt5+3gDzm6n4KDd9Y+Xw+Fxv4sGl4CPMp3vOAXI08B8927dZktvgSO8Rku93Hr/MmT2g1dMw27ZNcfO1jrtf8xDLx6uSmi8azae1tvZr6t5cxRmIY2z0K7ZohG2vYHFhs8u9uzBEmpcFeGzkU281PLuzGYU2hG+MD+drBRocNiJU5+pLnuatPduv6/N9hEVwaHmK6vbemy5F04+Z0Bdv48OuW8vjbH89yT8n6iDe6hqe8s5oODyvanJtnXcS0PuQxuUY/jLlAuqV9eiosYnUhpru5aRSXc+CXrmsuOuwaTucmXnk4MHe9XcQodny7OxvPss1qch3Yc7fBQDw+DWODT+SwR1935OCu8VKfgLGxXP/ToCAuDQ+hMFZNoTI5FJJzMEa3h2TTudN8NN03QK4pEXML87X1pzkOawK02NADY7lyHg6JP8vuh318BpMs9QlkeosDc/izkEEj7T99YUaIyXEjxMd8zLGSE1Lc5oDJnte6VFOGvMSATI5MxPl6sYXW7n7Y8LnYkG6pJnTGWxwYb9jKYkKbiwZizTbdhBH80t1s2JjH7v52u/MAk2w+6cE45zhHYKbdAwNjHogYXe2wosPHn6znWbbDPgE64/UHBiiO1didQseC/I1J46XmopH28GeEOOk2hwabfG0+jXc3EsaYTOQ04guwVBN+u1ot+LIf8JML7Lk7SLJt1m22pT6hMd7jwAAFsqDruq5QIAVJEpppcwOzxT99HXI3zNTNa+xuJjldsdO88BMr0wbztS8VOumnNWFDC/iIlctJucaDFIeimyMw+7RPMr3PgSmKoiiKoiiKoiiKoiiKoiheysfHXxBUQfWvUXBZAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIsAAAAhCAYAAADpnlh3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMXSURBVHhe7ZaBbeMwDEW7z63SUTpIBsmcyfExnwIlx7LSS5oewAe4tshPSqRkpx9FURRFURRFURRFURRFURRFURRFscrlcvlzvV5PdjXMdrbrU5LQYP+S6aU8Y76U4yxT8S9YIz9pqHGiuTK3A2R33yyN/7fD8kUOIJ/MxXdRL08a7vKMzXuEZ8yn+DN347DGYgIbQRfZGJl2yZvHs12+Cdwl6UCHP7Bx+0kLyGOu7ufP8E2Vz+dzsYEPm4ZTmE/xngfkauQ5eLZrtyazxRfYISbb7T5+lTd5QquhY7bDPsnFVz7m+vmfVSZdndh00XQ2rL2lN1P/1jLGSAxju0eRXSNkYw2bw4pN/t1NmWFSmuu1kUOx3fzkwm5MawrdGB/I1w41OmxArMzRlzzPQ32yW9fnH4UFcGk4xXR7b0uXI+nGjemKtfH0q5by+Fsfz3IfkvURb3TNTnmPapoeVLQ5N8+6iGl9yGNyjX4Yc4F0S/v0MljA6iJMd3fDKCznwC9d11h02DU8nJt45eGwPPRWEaPY8a3ubDzLdlST68Ceu80F4vFpGJv7SQ579HVHDu4aL/UJGBvL9b8EiuHScApFsWKKlMmhiJyDMbo9JDucO81Hw735ch0SMfcwX1t/mmNaE6DFhh4Yy5XzcED8WXY/6OMzmGSpTyDT2w/L9Kcgg0bab31ZRojJcSPEx3zMsZITUtzmcMme17pUU4a8xIBMjkzE+XqxhdbuftDwudiQbqkmdMbbD4s3a2Uhoc0FA7FmO9yAEfzS3W3WmMfu/la7c4JJNp/xYJxznCMw0+5hgTEPRIyudlDR4eNP1vMs27RPgM5472EBCmMldqfIsRh/U9J4qbFopJ3+dBAn3ebAYJOvzafx7ibCGJOJnEa8+Us14ber1YIv+wE/ucCeu0Mk22bdZlvqExrj/YcFKI7F3NZ0g+IoRpLQHDY2MFv8g9chd8NM3bzG7kaS0xU7jQs/sTJtMF/7QqGT/rAmbGgBH7FyOSnXeIjiQHRzBGY/7JNMv+OwFEVRFEVRFEVRFEVRFEXxCB8ffwGvgEH15eyJmAAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 8.000000 1.000000 L 131.000000 1.000000 L 133.750000 1.562500 L 135.937500 3.062500 L 137.437500 5.312500 L 138.000000 8.000000 L 138.000000 25.000000 L 137.437500 27.750000 L 135.937500 29.937500 L 133.750000 31.437500 L 131.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","i":"images/button40037.png","irol":"images/button40037_over.png","ion":"images/button40037_down.png","idis":"images/button40037_disabled.png"}
,
"button40031":{"x":919,"y":614,"w":67.000000,"h":33.000000,"stylemods":[{"sel":"div.button40031Text","decl":" { position:fixed; left:4px; top:3px; width:59px; height:27px;}"},{"sel":"span.button40031Text","decl":" { display:table-cell; position:relative; width:59px; height:27px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAAhCAYAAACC9hYiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFQSURBVGhD7ZVRcsIwDERzn16Fo3AQDsI5A3pC8siOw/SnTWj3zWRsrdaOLAwsQgghhBBCCPHprOv69TBsvIfUYanbXu7Pkc0Am19Dbpj84814vf1xi/A4ajOAOFKOSf+vGTZevaShKOJZM4rfsfgSKSfzo25S28/G7oMIjmtKFkTRFJLzSE+bUXx+i2LtrCF39Ajru8bbB6e6GX4QL8vwpGHTrhmjP8GDN8IG3tTx2DP7XWqeQxkPx+ilRXGMHII5cBiSrAvJwYceYSP3Y4+6T4W8cb5mAIWlxrweInN7hK2D9eTqOyq+8KzNAC/vxbduxh7F/5k3A4i9RKMeovg33/2R4r3k3Ngcek//dWrBITVMy+vdfaIWT/82R/AY7ZD4EcZ17M8T4XFYEe+akblNofjRyVciTSM2f8mAjo+9Q/L3lL2OvyFCCCGEEOIdy/IElTLCsgl11f4AAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAAhCAYAAACC9hYiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFQSURBVGhD7ZVRcsIwDERzn16Fo3AQDsI5A3pC8siOw/SnTWj3zWRsrdaOLAwsQgghhBBCCPHprOv69TBsvIfUYanbXu7Pkc0Am19Dbpj84814vf1xi/A4ajOAOFKOSf+vGTZevaShKOJZM4rfsfgSKSfzo25S28/G7oMIjmtKFkTRFJLzSE+bUXx+i2LtrCF39Ajru8bbB6e6GX4QL8vwpGHTrhmjP8GDN8IG3tTx2DP7XWqeQxkPx+ilRXGMHII5cBiSrAvJwYceYSP3Y4+6T4W8cb5mAIWlxrweInN7hK2D9eTqOyq+8KzNAC/vxbduxh7F/5k3A4i9RKMeovg33/2R4r3k3Ngcek//dWrBITVMy+vdfaIWT/82R/AY7ZD4EcZ17M8T4XFYEe+akblNofjRyVciTSM2f8mAjo+9Q/L3lL2OvyFCCCGEEOIdy/IElTLCsgl11f4AAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAAAiCAYAAADmvn/1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFRSURBVGhD7ZXRbcMwDES9T1bJKBkkg2ROp3wMKVCyXOSjhd3mHmBIPJ5kihaSRQghhBBCCCE+jXVdL0/DxkdIHZa67+X+JdkQsPkt5IbJv96Q19uf9wiPpTYEiCPlmPSZDbHx5mUNhRHPGlL8jsXXSDmZH3WT2n42dh8jOLYxWRSFU0zOIz1tSPH5bYq1s6Y80COs7xpvIZzuhvhhvDTDk4ZNu4aM/gQP3ggbeFPHY8/sd6p5Dmc8IKOXFwUychDmwIFIsi4kBx96hI3cjz3qPhXyxjkbAhSXGvN6kMztEbYO1pOr76j4wjM3BLzEF2/dkD2K/+/eECD2Mo16kOLf/BaMFO8158bm4Hv6IdSiQ2qYlle9+7IWT/9SR/AY7aD4EcZ17M8T4bFYId81JHObYvGjk69EmmZs/q4BHR97h+TvKXud46YIIYQQQgjxwyzLF56FwrL1Ff2NAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAAhCAYAAACC9hYiAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFQSURBVGhD7ZVRcsIwDERzn16Fo3AQDsI5A3pC8siOw/SnTWj3zWRsrdaOLAwsQgghhBBCCPHprOv69TBsvIfUYanbXu7Pkc0Am19Dbpj84814vf1xi/A4ajOAOFKOSf+vGTZevaShKOJZM4rfsfgSKSfzo25S28/G7oMIjmtKFkTRFJLzSE+bUXx+i2LtrCF39Ajru8bbB6e6GX4QL8vwpGHTrhmjP8GDN8IG3tTx2DP7XWqeQxkPx+ilRXGMHII5cBiSrAvJwYceYSP3Y4+6T4W8cb5mAIWlxrweInN7hK2D9eTqOyq+8KzNAC/vxbduxh7F/5k3A4i9RKMeovg33/2R4r3k3Ngcek//dWrBITVMy+vdfaIWT/82R/AY7ZD4EcZ17M8T4XFYEe+akblNofjRyVciTSM2f8mAjo+9Q/L3lL2OvyFCCCGEEOIdy/IElTLCsgl11f4AAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 8.000000 1.000000 L 59.000000 1.000000 L 61.750000 1.562500 L 63.937500 3.062500 L 65.437500 5.312500 L 66.000000 8.000000 L 66.000000 25.000000 L 65.437500 27.750000 L 63.937500 29.937500 L 61.750000 31.437500 L 59.000000 32.000000 L 8.000000 32.000000 L 5.375000 31.500000 L 3.062500 30.000000 L 1.562500 27.687500 L 1.000000 25.000000 L 1.000000 8.000000 L 1.562500 5.312500 L 3.062500 3.062500 L 5.312500 1.562500 L 8.000000 1.000000 z","i":"images/button40031.png","irol":"images/button40031_over.png","ion":"images/button40031_down.png","idis":"images/button40031_disabled.png"}
,
"image77":{"x":1041,"y":245,"w":300,"h":175,"bOffBottom":0,"i":"images/rotatephone-300x175.png"}
,
"text75":{"x":1232,"y":486,"w":200,"h":80,"txtscale":100,"bOffBottom":0}
,
"image40071":{"x":653,"y":135,"w":318,"h":479,"bOffBottom":0,"i":"images/hellfire_medium_hot_burger_question.jpg"}
,
"text40074":{"x":240,"y":300,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40075":{"x":224,"y":216,"w":201,"h":79,"bOffBottom":0,"i":"images/habanero-sauce_72dpi_webready_small.png"}
,
"text40077":{"x":456,"y":300,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40078":{"x":439,"y":214,"w":201,"h":83,"bOffBottom":0,"i":"images/reaper-sauce_72dpi_webready_small.png"}
,
"text40080":{"x":456,"y":563,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40081":{"x":439,"y":474,"w":201,"h":84,"bOffBottom":0,"i":"images/lettuce_72dpi_webready_small.png"}
,
"text40083":{"x":1034,"y":519,"w":118,"h":19,"txtscale":100,"bOffBottom":0}
,
"image40084":{"x":215,"y":358,"w":202,"h":76,"bOffBottom":0,"i":"images/buttermilkpatty_small.png"}
,
"text40086":{"x":240,"y":563,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40087":{"x":227,"y":466,"w":195,"h":101,"bOffBottom":0,"i":"images/cheese_slice_72dpi_webready_small.png"}
,
"text40089":{"x":240,"y":435,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40090":{"x":242,"y":337,"w":202,"h":77,"bOffBottom":0,"i":"images/buttermilkpatty_small.png"}
,
"text40092":{"x":22,"y":435,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40093":{"x":3,"y":339,"w":205,"h":84,"bOffBottom":0,"i":"images/mayo_72dpi_webready_small.png"}
,
"text40095":{"x":22,"y":563,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40096":{"x":11,"y":472,"w":188,"h":88,"bOffBottom":0,"i":"images/tomato_slice_72dpi_webready_small.png"}
,
"text40098":{"x":22,"y":300,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40099":{"x":3,"y":213,"w":205,"h":84,"bOffBottom":0,"i":"images/chilli_aioli_circle.png"}
,
"text40101":{"x":456,"y":435,"w":165,"h":37,"txtscale":100,"bOffBottom":0}
,
"image40102":{"x":463,"y":334,"w":153,"h":94,"bOffBottom":0,"i":"images/short-cut-bacon_small.png"}
,
"image40046":{"x":923,"y":524,"w":70,"h":70,"bOffBottom":0,"i":"images/check.png"}
,
"image40043":{"x":929,"y":530,"w":58,"h":58,"bOffBottom":0,"i":"images/cross_3.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
dragMgr.addDrop( 656, 234, 140, 51, '1', Update_qu40066 );
dragMgr.addDrop( 829, 234, 142, 51, '2', Update_qu40066 );
dragMgr.addDrop( 719, 287, 183, 51, '3', Update_qu40066 );
dragMgr.addDrop( 719, 340, 181, 48, '4', Update_qu40066 );
dragMgr.addDrop( 719, 391, 181, 51, '5', Update_qu40066 );
dragMgr.addDrop( 719, 444, 181, 51, '6', Update_qu40066 );
dragMgr.addDrop( 719, 497, 181, 46, '7', Update_qu40066 );

Init_qu40066(false, true);
}
,
"RCDResultResize":function(){}
,"preload":['images/rr160_operationdeclutter_redops_redspace_header_fa.jpg','images/rotatephone-300x175.png','images/check.png','images/cross_3.png','images/cheese_slice_72dpi_webready_small.png','images/buttermilkpatty_small.png','images/lettuce_72dpi_webready_small.png','images/tomato_slice_72dpi_webready_small.png','images/mayo_72dpi_webready_small.png','images/short-cut-bacon_small.png','images/chilli_aioli_circle.png','images/hellfire_medium_hot_burger_question.jpg','images/habanero-sauce_72dpi_webready_small.png','images/reaper-sauce_72dpi_webready_small.png','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/shape74.png','images/button40037.png','images/button40037_over.png','images/button40037_down.png','images/button40037_disabled.png','images/button40031.png','images/button40031_over.png','images/button40031_down.png','images/button40031_disabled.png']
}}
