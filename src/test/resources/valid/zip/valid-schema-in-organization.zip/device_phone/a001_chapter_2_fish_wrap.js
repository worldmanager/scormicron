PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":515,"bgColor":"#ffffff"}
,
"shape74":{"x":-1,"y":471,"w":786.000000,"h":45.000000,"stylemods":[{"sel":"div.shape74Text","decl":" { position:fixed; left:3px; top:3px; width:780px; height:39px;}"},{"sel":"span.shape74Text","decl":" { display:table-cell; position:relative; width:780px; height:39px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxIAAAAtCAYAAAA6AF0uAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACgSURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAfNSjzAAEPqJqzAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 785.000000 1.000000 L 785.000000 44.000000 L 1.000000 44.000000 L 1.000000 1.000000 z"}
,
"image60":{"x":0,"y":0,"w":787,"h":116,"bOffBottom":0,"i":"images/rr160_operationdeclutter_redops_redspace_header_fa.jpg"}
,
"button53701":{"x":17,"y":480,"w":109.000000,"h":26.000000,"stylemods":[{"sel":"div.button53701Text","decl":" { position:fixed; left:4px; top:3px; width:101px; height:20px;}"},{"sel":"span.button53701Text","decl":" { display:table-cell; position:relative; width:101px; height:20px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG0AAAAaCAYAAAC939IvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAH6SURBVGhD7ZaJccJADEXph1ZSCoVQSOok+U98LbtmDSRD4kzQm9Gg29rDcXZFURRFURRFURRFUWzM6XTaS94/DLrkjZjMIxKJT0B9D/S3+RDM4rn2dr02bIQ3JA4J8EliYzkwJAJPQH2/c2hxoai167VhQ25txtaHpty4QF+t+9f4Bq/+2clDs8SfToeC9JvhcLHP7ktdv/k817H2li9xPnKVK3N1NvKx8YN9B6ltRsebTR511qfrokfWEbD792BAHpyDzsjhlJPfuF4/Sm9vqfThW2h76E0+fvS+1xp9D3oiERC2V2dD0BP6kNPr+s0L9JY6ddKn68Lvuptz/yge4O6bZnO5gHaTE/lisdavFkacOsvNbxT15NkMm742780WucSlt/U5h7cw3+CwnRfz4DuXXuhi7dJthgccbmQPsT5OvqQdmmS68V7o6qHRk1+7p/jZV2RfqauzJbKHNwPbMhyWc+JwHZuuCz9xm9ugAfLf6Tak9FgMOr+pAwNTY31YbA81zh1i1OBHz5wITKC31QY1yFIHP292UdohEFcNM8dzlzaQa9/Vuoj1uZvBcAzCoIAueeg2S48FJtgOZW0DH3F6RIJA7+1EPjazPTeRP79FcbH6HPfq506GPjiUl4eY/YY3Cxt/0uX/jUMriqIoiqIoiqIonshu9wn5Qy3lrpxEQgAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG0AAAAaCAYAAAC939IvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAH6SURBVGhD7ZaJccJADEXph1ZSCoVQSOok+U98LbtmDSRD4kzQm9Gg29rDcXZFURRFURRFURRFUWzM6XTaS94/DLrkjZjMIxKJT0B9D/S3+RDM4rn2dr02bIQ3JA4J8EliYzkwJAJPQH2/c2hxoai167VhQ25txtaHpty4QF+t+9f4Bq/+2clDs8SfToeC9JvhcLHP7ktdv/k817H2li9xPnKVK3N1NvKx8YN9B6ltRsebTR511qfrokfWEbD792BAHpyDzsjhlJPfuF4/Sm9vqfThW2h76E0+fvS+1xp9D3oiERC2V2dD0BP6kNPr+s0L9JY6ddKn68Lvuptz/yge4O6bZnO5gHaTE/lisdavFkacOsvNbxT15NkMm742780WucSlt/U5h7cw3+CwnRfz4DuXXuhi7dJthgccbmQPsT5OvqQdmmS68V7o6qHRk1+7p/jZV2RfqauzJbKHNwPbMhyWc+JwHZuuCz9xm9ugAfLf6Tak9FgMOr+pAwNTY31YbA81zh1i1OBHz5wITKC31QY1yFIHP292UdohEFcNM8dzlzaQa9/Vuoj1uZvBcAzCoIAueeg2S48FJtgOZW0DH3F6RIJA7+1EPjazPTeRP79FcbH6HPfq506GPjiUl4eY/YY3Cxt/0uX/jUMriqIoiqIoiqIonshu9wn5Qy3lrpxEQgAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG4AAAAbCAYAAACdtLqJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAH5SURBVGhD7ZaNccIwDEbZh1UYhUEYpHPS6olPxk4coD1a2t737nToP3JsN90ZY4wxxhhjjDHmD3A+n/chb+8CPeRALMwTkolPIPoe6S/zIZhFc+3lMrwMvZTcKMAXki+XTUMy8ASi71c2Lg8VtXIZXsqtF/LqjYvcPESfrfv36CRv/gmqjZPkn1GFkvKLYYOxL+5rXb8BPFexdtuXKB9Z5Ya5ORv52PhBvmOobUbFm00eddKn66JH1RGQ+2dhSB5ew86oASOnvnm9fgq93dbQh2+j7KE3+fjR+15b9D3oiWQgkL05G4Je0IecXo/fOkSH0qkLfbou/Kq7Ofe3oyHu3jiZy0W0E12ELxcsfbU44tRJbn6zqCdPZtr0lXlvtswlHnpbn3K4jXWT01ZezoPvUnqli7WD91I05HAye4j1cfJD2saFTF++Fru5cfTkV+4pevaK6hvq5mxF2MMNwZYMG6ac3GDFpuvCT1zm64gh6l/tNmjouSB0fksHhqZG+rDgHmqUO8SowY9eORmYQG+pDWqQpQ563uywtI0gHjXMnM9d2kCufKt1EetzXwoDMgzDAnrIQ6c69Fxkga1Q1TbwEadHJgTovV2EjxfanluEv75Nebj6HPXq5y6GPjgirzay+g03DBt/0eX/no0zxhhjjDHGGGPMPXa7D7Z/LeV7FvxrAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG0AAAAaCAYAAAC939IvAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAH6SURBVGhD7ZaJccJADEXph1ZSCoVQSOok+U98LbtmDSRD4kzQm9Gg29rDcXZFURRFURRFURRFUWzM6XTaS94/DLrkjZjMIxKJT0B9D/S3+RDM4rn2dr02bIQ3JA4J8EliYzkwJAJPQH2/c2hxoai167VhQ25txtaHpty4QF+t+9f4Bq/+2clDs8SfToeC9JvhcLHP7ktdv/k817H2li9xPnKVK3N1NvKx8YN9B6ltRsebTR511qfrokfWEbD792BAHpyDzsjhlJPfuF4/Sm9vqfThW2h76E0+fvS+1xp9D3oiERC2V2dD0BP6kNPr+s0L9JY6ddKn68Lvuptz/yge4O6bZnO5gHaTE/lisdavFkacOsvNbxT15NkMm742780WucSlt/U5h7cw3+CwnRfz4DuXXuhi7dJthgccbmQPsT5OvqQdmmS68V7o6qHRk1+7p/jZV2RfqauzJbKHNwPbMhyWc+JwHZuuCz9xm9ugAfLf6Tak9FgMOr+pAwNTY31YbA81zh1i1OBHz5wITKC31QY1yFIHP292UdohEFcNM8dzlzaQa9/Vuoj1uZvBcAzCoIAueeg2S48FJtgOZW0DH3F6RIJA7+1EPjazPTeRP79FcbH6HPfq506GPjiUl4eY/YY3Cxt/0uX/jUMriqIoiqIoiqIonshu9wn5Qy3lrpxEQgAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 7.000000 1.000000 L 102.000000 1.000000 L 104.312500 1.500000 L 106.250000 2.750000 L 107.500000 4.687500 L 108.000000 7.000000 L 108.000000 19.000000 L 107.500000 21.312500 L 106.250000 23.250000 L 104.312500 24.500000 L 102.000000 25.000000 L 7.000000 25.000000 L 4.750000 24.562500 L 2.812500 23.250000 L 1.500000 21.312500 L 1.000000 19.000000 L 1.000000 7.000000 L 1.500000 4.687500 L 2.750000 2.750000 L 4.687500 1.500000 L 7.000000 1.000000 z"}
,
"button53695":{"x":715,"y":480,"w":53.000000,"h":26.000000,"stylemods":[{"sel":"div.button53695Text","decl":" { position:fixed; left:4px; top:3px; width:45px; height:20px;}"},{"sel":"span.button53695Text","decl":" { display:table-cell; position:relative; width:45px; height:20px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAAaCAYAAAAXHBSTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADdSURBVFhH7ZPbEYIwFETpx1YoxUIohDrRPXFvSNBPBWHumclwH3nsEhiSJEmSJDkJy7LcH8JpRfVZ4+b0XIQpMblUuIKpCVeKR5e/Yop92d/pfnBoDIy5/GYKgfRNvVXiT3nsF7R7/RwOZziedX4RSBxCqMUccG97q+wzErt8/E05HuOtalRTxNRbVOvEutzdiNLjTYGFYKgz1c7Zol55GRBrQOl/mIKXvFUg/Tbf4h6fXvdfKuz+t91ACMNpAYGI07OaCMFBrNGzu0W1qhHWl8mCuExIkiRJkkswDE/+TJvrmkk+kwAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAAaCAYAAAAXHBSTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADdSURBVFhH7ZPbEYIwFETpx1YoxUIohDrRPXFvSNBPBWHumclwH3nsEhiSJEmSJDkJy7LcH8JpRfVZ4+b0XIQpMblUuIKpCVeKR5e/Yop92d/pfnBoDIy5/GYKgfRNvVXiT3nsF7R7/RwOZziedX4RSBxCqMUccG97q+wzErt8/E05HuOtalRTxNRbVOvEutzdiNLjTYGFYKgz1c7Zol55GRBrQOl/mIKXvFUg/Tbf4h6fXvdfKuz+t91ACMNpAYGI07OaCMFBrNGzu0W1qhHWl8mCuExIkiRJkkswDE/+TJvrmkk+kwAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAbCAYAAAA3d3w1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADeSURBVFhH7ZPbDYMwEATdT1qhlBRCIdRJsuPsGZvkM0KAbiSLe9iXXRxKkiRJkiQ3Yl3X50s4bai+aD2cXo8wJmaXKncxNuNM8eTyX4wxl/lOj4UfjoU5l7+MIZK+abdL/CuPeUE/6xAQwHK8SEMVSRxiqMUecG9/u8yZiF0+x405nuLtajVjxNR7VBsEuzzcjNJzGAOLwdRgrN+zR736QiDOgNLzGIOPxE0k/T7f4x5/w+E7VTh8f4eCGJbTCiIRqGczEqKDOKPncJtqNTOcr5sFcd2QJEmSJMnVKeUNm3ib61X9U1MAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAAaCAYAAAAXHBSTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADdSURBVFhH7ZPbEYIwFETpx1YoxUIohDrRPXFvSNBPBWHumclwH3nsEhiSJEmSJDkJy7LcH8JpRfVZ4+b0XIQpMblUuIKpCVeKR5e/Yop92d/pfnBoDIy5/GYKgfRNvVXiT3nsF7R7/RwOZziedX4RSBxCqMUccG97q+wzErt8/E05HuOtalRTxNRbVOvEutzdiNLjTYGFYKgz1c7Zol55GRBrQOl/mIKXvFUg/Tbf4h6fXvdfKuz+t91ACMNpAYGI07OaCMFBrNGzu0W1qhHWl8mCuExIkiRJkkswDE/+TJvrmkk+kwAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 7.000000 1.000000 L 46.000000 1.000000 L 48.312500 1.500000 L 50.250000 2.750000 L 51.500000 4.687500 L 52.000000 7.000000 L 52.000000 19.000000 L 51.500000 21.312500 L 50.250000 23.250000 L 48.312500 24.500000 L 46.000000 25.000000 L 7.000000 25.000000 L 4.750000 24.562500 L 2.812500 23.250000 L 1.500000 21.312500 L 1.000000 19.000000 L 1.000000 7.000000 L 1.500000 4.687500 L 2.750000 2.750000 L 4.687500 1.500000 L 7.000000 1.000000 z"}
,
"image77":{"x":790,"y":191,"w":233,"h":136,"bOffBottom":0,"i":"images/rotatephone-300x175.png"}
,
"text75":{"x":790,"y":378,"w":156,"h":62,"txtscale":100,"bOffBottom":0}
,
"text53718":{"x":18,"y":123,"w":567,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53720":{"x":430,"y":187,"w":294,"h":262,"bOffBottom":0,"i":"images/fish_wrap_question.jpg"}
,
"text53721":{"x":26,"y":347,"w":166,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53723":{"x":9,"y":267,"w":216,"h":74,"bOffBottom":0,"i":"images/fish_fillets_x2.png"}
,
"text53724":{"x":237,"y":347,"w":166,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53726":{"x":209,"y":259,"w":217,"h":89,"bOffBottom":0,"i":"images/lettuce_72dpi_webready_small.png"}
,
"text53727":{"x":26,"y":440,"w":166,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53729":{"x":5,"y":380,"w":223,"h":53,"bOffBottom":0,"i":"images/classic_herb_mayo_sauce_zigzag_72dpi_webready_small.png"}
,
"text53730":{"x":237,"y":241,"w":166,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53732":{"x":215,"y":167,"w":205,"h":72,"bOffBottom":0,"i":"images/shredded_cheese_72dpi_webready_small.png"}
,
"text53733":{"x":237,"y":440,"w":166,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53735":{"x":205,"y":378,"w":223,"h":57,"bOffBottom":0,"i":"images/chilli_aioli_zigzag.png"}
,
"text53736":{"x":26,"y":237,"w":166,"h":29,"txtscale":100,"bOffBottom":0}
,
"image53738":{"x":16,"y":167,"w":201,"h":72,"bOffBottom":0,"i":"images/tomato_x2.png"}
,
"image53710":{"x":718,"y":408,"w":54,"h":54,"bOffBottom":0,"i":"images/check.png"}
,
"image53707":{"x":723,"y":412,"w":45,"h":45,"bOffBottom":0,"i":"images/cross_3.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
dragMgr.addDrop( 481, 187, 190, 62, '1', Update_qu53717 );
dragMgr.addDrop( 481, 252, 190, 62, '2', Update_qu53717 );
dragMgr.addDrop( 482, 318, 186, 59, '3', Update_qu53717 );

Init_qu53717(false, true);
}
,
"RCDResultResize":function(){}
,"preload":[]
},
"480":{
"pageLayer":{"w":480,"h":1034,"bgColor":"#ffffff"}
,
"shape74":{"x":-1,"y":954,"w":483.000000,"h":30.000000,"stylemods":[{"sel":"div.shape74Text","decl":" { position:fixed; left:3px; top:3px; width:477px; height:24px;}"},{"sel":"span.shape74Text","decl":" { display:table-cell; position:relative; width:477px; height:24px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeMAAAAeCAYAAAAfDHZLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABPSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCgBuKGAAEeuTpyAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 482.000000 1.000000 L 482.000000 29.000000 L 1.000000 29.000000 L 1.000000 1.000000 z"}
,
"image60":{"x":0,"y":0,"w":481,"h":71,"bOffBottom":0,"i":"images/rr160_operationdeclutter_redops_redspace_header_fa.jpg"}
,
"button53701":{"x":60,"y":1012,"w":41.000000,"h":23.000000,"stylemods":[{"sel":"div.button53701Text","decl":" { position:fixed; left:4px; top:3px; width:33px; height:17px;}"},{"sel":"span.button53701Text","decl":" { display:table-cell; position:relative; width:33px; height:17px; vertical-align:middle; text-align:center; line-height:10px; font-size:10px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADhSURBVEhL7ZTRDcIwDES7T1dhFAZhkM5Z8DPnNrRJCOIDPvykiLMd21eKmJIkSf6QdV0vdpb7zk0laleOwq9gLrsUjkMTrspmGfNY+ucml15jmGSBHmZRidpMfMxD3Af6I2c6Hr679wUNmRWeYIHu+MBS2yeLvNfSGNjMcNAlusNP67O3Y41vTZYDTW/fAL0H3BiiNpM6hxlKjVEurWG1rknTNTNNk8xSvbnzBJePTeiI7bNnsvlaW3l6OaarD9JEjUN/QdzjvsIwFGx96GfKzXi/STeJJscsdJIkSTLKND0ARYuyzH6L4C8AAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADhSURBVEhL7ZTRDcIwDES7T1dhFAZhkM5Z8DPnNrRJCOIDPvykiLMd21eKmJIkSf6QdV0vdpb7zk0laleOwq9gLrsUjkMTrspmGfNY+ucml15jmGSBHmZRidpMfMxD3Af6I2c6Hr679wUNmRWeYIHu+MBS2yeLvNfSGNjMcNAlusNP67O3Y41vTZYDTW/fAL0H3BiiNpM6hxlKjVEurWG1rknTNTNNk8xSvbnzBJePTeiI7bNnsvlaW3l6OaarD9JEjUN/QdzjvsIwFGx96GfKzXi/STeJJscsdJIkSTLKND0ARYuyzH6L4C8AAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAYCAYAAACMcW/9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADhSURBVFhH7ZTRDcIwDES7T1dhFAZhkM5Z8DPnELVJaMUPCD8p6tmO7YMipiRJkh9jXdeLneX+4qYStStH4Ucwl10Kz0EjzuoBMuex9FcYXUbNYZQl+kCLStRm4m0e4j7QHznT8QUM9+7QoFnhDpbojg+ttT1Z5r2WxkQxxEHX6A4/s/NvyZrfGq2Hmi7fBL0b3ByiNZM6hxlKHade3MJqQ6OmW4a6RpmlendnExq2jeiI7Tky2n3FvTy9HNPNDzNEzYf+nrjHfYVhKih96GfKDXm/STeKJscsdJIkSfKXTNMDGE+yzHYozcQAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADhSURBVEhL7ZTRDcIwDES7T1dhFAZhkM5Z8DPnNrRJCOIDPvykiLMd21eKmJIkSf6QdV0vdpb7zk0laleOwq9gLrsUjkMTrspmGfNY+ucml15jmGSBHmZRidpMfMxD3Af6I2c6Hr679wUNmRWeYIHu+MBS2yeLvNfSGNjMcNAlusNP67O3Y41vTZYDTW/fAL0H3BiiNpM6hxlKjVEurWG1rknTNTNNk8xSvbnzBJePTeiI7bNnsvlaW3l6OaarD9JEjUN/QdzjvsIwFGx96GfKzXi/STeJJscsdJIkSTLKND0ARYuyzH6L4C8AAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 6.000000 1.000000 L 35.000000 1.000000 L 36.937500 1.375000 L 38.562500 2.500000 L 39.625000 4.062500 L 40.000000 6.000000 L 40.000000 17.000000 L 39.625000 18.937500 L 38.562500 20.562500 L 36.937500 21.625000 L 35.000000 22.000000 L 6.000000 22.000000 L 4.125000 21.625000 L 2.500000 20.562500 L 1.375000 18.937500 L 1.000000 17.000000 L 1.000000 6.000000 L 1.375000 4.062500 L 2.500000 2.500000 L 4.062500 1.375000 L 6.000000 1.000000 z"}
,
"button53695":{"x":1286,"y":795,"w":41.000000,"h":23.000000,"stylemods":[{"sel":"div.button53695Text","decl":" { position:fixed; left:4px; top:3px; width:33px; height:17px;}"},{"sel":"span.button53695Text","decl":" { display:table-cell; position:relative; width:33px; height:17px; vertical-align:middle; text-align:center; line-height:10px; font-size:10px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZLLDQMhDETpJ61sKSkkhVDnEj/Ls/KizSUon4OfhIwHg0cWrSiKolhnjPHY971H6oS2Rfp7MGRrmKl7SMsm4/7x3jJ6EKMhnUxavNnqnBO9wKCGFSl1PWo3akUcr2HvuCEiK2vs1TzpeeIY39Am/VS3TDakprM2kafnU7N49ac/Y1JNs0Zie5/kjOotfs8kkEdjmTz9vYzMEbMp9q/uvAWPyZAw7TAJ1KAF3jyM+YSJHOiOciAviqL4S1p7AnL5ZlPytMImAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZLLDQMhDETpJ61sKSkkhVDnEj/Ls/KizSUon4OfhIwHg0cWrSiKolhnjPHY971H6oS2Rfp7MGRrmKl7SMsm4/7x3jJ6EKMhnUxavNnqnBO9wKCGFSl1PWo3akUcr2HvuCEiK2vs1TzpeeIY39Am/VS3TDakprM2kafnU7N49ac/Y1JNs0Zie5/kjOotfs8kkEdjmTz9vYzMEbMp9q/uvAWPyZAw7TAJ1KAF3jyM+YSJHOiOciAviqL4S1p7AnL5ZlPytMImAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAYCAYAAACMcW/9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVFhH7ZJBDgMhCEW9T6/iUXqQHsRzankEJmimm87YdMFLDPJF/CGWJEmSZD9jjFfvvVmqmFYt/Q8wJWuIsadJl43a/aPfLXhTzJo0GZX4kNU4J2qBQA3LUuqa1VZqHTu+jvRSU0RW1Ni7gaDHyWO+oi36VHcL0ZQ/vGoLcYo6PYlnf3yfUX84aiSy14mueL3E3xoFcnvcjU5/MeIGidEY+093voaGbsoR7TAK1KAZasDM6aSJHPgdz4E8SZIk2Ukpb67bZlMN6NypAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZLLDQMhDETpJ61sKSkkhVDnEj/Ls/KizSUon4OfhIwHg0cWrSiKolhnjPHY971H6oS2Rfp7MGRrmKl7SMsm4/7x3jJ6EKMhnUxavNnqnBO9wKCGFSl1PWo3akUcr2HvuCEiK2vs1TzpeeIY39Am/VS3TDakprM2kafnU7N49ac/Y1JNs0Zie5/kjOotfs8kkEdjmTz9vYzMEbMp9q/uvAWPyZAw7TAJ1KAF3jyM+YSJHOiOciAviqL4S1p7AnL5ZlPytMImAAAAAElFTkSuQmCC"  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 6.000000 1.000000 L 35.000000 1.000000 L 36.937500 1.375000 L 38.562500 2.500000 L 39.625000 4.062500 L 40.000000 6.000000 L 40.000000 17.000000 L 39.625000 18.937500 L 38.562500 20.562500 L 36.937500 21.625000 L 35.000000 22.000000 L 6.000000 22.000000 L 4.125000 21.625000 L 2.500000 20.562500 L 1.375000 18.937500 L 1.000000 17.000000 L 1.000000 6.000000 L 1.375000 4.062500 L 2.500000 2.500000 L 4.062500 1.375000 L 6.000000 1.000000 z"}
,
"image77":{"x":75,"y":249,"w":338,"h":196,"bOffBottom":0,"i":"images/rotatephone-300x175.png"}
,
"text75":{"x":27,"y":157,"w":423,"h":62,"txtscale":100,"bOffBottom":0}
,
"text53718":{"x":524,"y":96,"w":347,"h":74,"txtscale":100,"bOffBottom":0}
,
"image53720":{"x":611,"y":178,"w":261,"h":233,"bOffBottom":0,"i":"images/fish_wrap_question.jpg"}
,
"text53721":{"x":1037,"y":198,"w":85,"h":36,"txtscale":100,"bOffBottom":0}
,
"image53723":{"x":1037,"y":-5,"w":926,"h":688,"bOffBottom":0,"i":"images/fish_fillets_x2.png"}
,
"text53724":{"x":1037,"y":683,"w":61,"h":19,"txtscale":100,"bOffBottom":0}
,
"image53726":{"x":1037,"y":411,"w":658,"h":272,"bOffBottom":0,"i":"images/lettuce_72dpi_webready_small.png"}
,
"text53727":{"x":1037,"y":683,"w":86,"h":54,"txtscale":100,"bOffBottom":0}
,
"image53729":{"x":1037,"y":516,"w":704,"h":167,"bOffBottom":0,"i":"images/classic_herb_mayo_sauce_zigzag_72dpi_webready_small.png"}
,
"text53730":{"x":1037,"y":683,"w":86,"h":38,"txtscale":100,"bOffBottom":0}
,
"image53732":{"x":1037,"y":516,"w":704,"h":167,"bOffBottom":0,"i":"images/shredded_cheese_72dpi_webready_small.png"}
,
"text53733":{"x":1037,"y":683,"w":83,"h":38,"txtscale":100,"bOffBottom":0}
,
"image53735":{"x":1037,"y":475,"w":593,"h":208,"bOffBottom":0,"i":"images/chilli_aioli_zigzag.png"}
,
"text53736":{"x":1037,"y":683,"w":78,"h":19,"txtscale":100,"bOffBottom":0}
,
"image53738":{"x":1037,"y":461,"w":877,"h":222,"bOffBottom":0,"i":"images/tomato_x2.png"}
,
"image53710":{"x":439,"y":524,"w":33,"h":33,"bOffBottom":0,"i":"images/check.png"}
,
"image53707":{"x":442,"y":530,"w":28,"h":28,"bOffBottom":0,"i":"images/cross_3.png"}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
dragMgr.addDrop( 656, 178, 169, 55, '1', Update_qu53717 );
dragMgr.addDrop( 656, 236, 169, 55, '2', Update_qu53717 );
dragMgr.addDrop( 657, 294, 165, 53, '3', Update_qu53717 );

Init_qu53717(false, true);
}
,
"RCDResultResize":function(){}
,"preload":[]
}}
