PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":515,"bgColor":"#ffffff"}
,
"shape74":{"x":-1,"y":471,"w":786.000000,"h":45.000000,"stylemods":[{"sel":"div.shape74Text","decl":" { position:fixed; left:3px; top:3px; width:780px; height:39px;}"},{"sel":"span.shape74Text","decl":" { display:table-cell; position:relative; width:780px; height:39px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAxIAAAAtCAYAAAA6AF0uAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACgSURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAfNSjzAAEPqJqzAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 785.000000 1.000000 L 785.000000 44.000000 L 1.000000 44.000000 L 1.000000 1.000000 z"}
,
"button65":{"x":715,"y":480,"w":53.000000,"h":26.000000,"stylemods":[{"sel":"div.button65Text","decl":" { position:fixed; left:4px; top:3px; width:45px; height:20px;}"},{"sel":"span.button65Text","decl":" { display:table-cell; position:relative; width:45px; height:20px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAAaCAYAAAAXHBSTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADdSURBVFhH7ZPbEYIwFETpx1YoxUIohDrRPXFvSNBPBWHumclwH3nsEhiSJEmSJDkJy7LcH8JpRfVZ4+b0XIQpMblUuIKpCVeKR5e/Yop92d/pfnBoDIy5/GYKgfRNvVXiT3nsF7R7/RwOZziedX4RSBxCqMUccG97q+wzErt8/E05HuOtalRTxNRbVOvEutzdiNLjTYGFYKgz1c7Zol55GRBrQOl/mIKXvFUg/Tbf4h6fXvdfKuz+t91ACMNpAYGI07OaCMFBrNGzu0W1qhHWl8mCuExIkiRJkkswDE/+TJvrmkk+kwAAAABJRU5ErkJggg==" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAAaCAYAAAAXHBSTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADdSURBVFhH7ZPbEYIwFETpx1YoxUIohDrRPXFvSNBPBWHumclwH3nsEhiSJEmSJDkJy7LcH8JpRfVZ4+b0XIQpMblUuIKpCVeKR5e/Yop92d/pfnBoDIy5/GYKgfRNvVXiT3nsF7R7/RwOZziedX4RSBxCqMUccG97q+wzErt8/E05HuOtalRTxNRbVOvEutzdiNLjTYGFYKgz1c7Zol55GRBrQOl/mIKXvFUg/Tbf4h6fXvdfKuz+t91ACMNpAYGI07OaCMFBrNGzu0W1qhHWl8mCuExIkiRJkkswDE/+TJvrmkk+kwAAAABJRU5ErkJggg==" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAbCAYAAAA3d3w1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADeSURBVFhH7ZPbDYMwEATdT1qhlBRCIdRJsuPsGZvkM0KAbiSLe9iXXRxKkiRJkiQ3Yl3X50s4bai+aD2cXo8wJmaXKncxNuNM8eTyX4wxl/lOj4UfjoU5l7+MIZK+abdL/CuPeUE/6xAQwHK8SEMVSRxiqMUecG9/u8yZiF0+x405nuLtajVjxNR7VBsEuzzcjNJzGAOLwdRgrN+zR736QiDOgNLzGIOPxE0k/T7f4x5/w+E7VTh8f4eCGJbTCiIRqGczEqKDOKPncJtqNTOcr5sFcd2QJEmSJMnVKeUNm3ib61X9U1MAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAAAaCAYAAAAXHBSTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADdSURBVFhH7ZPbEYIwFETpx1YoxUIohDrRPXFvSNBPBWHumclwH3nsEhiSJEmSJDkJy7LcH8JpRfVZ4+b0XIQpMblUuIKpCVeKR5e/Yop92d/pfnBoDIy5/GYKgfRNvVXiT3nsF7R7/RwOZziedX4RSBxCqMUccG97q+wzErt8/E05HuOtalRTxNRbVOvEutzdiNLjTYGFYKgz1c7Zol55GRBrQOl/mIKXvFUg/Tbf4h6fXvdfKuz+t91ACMNpAYGI07OaCMFBrNGzu0W1qhHWl8mCuExIkiRJkkswDE/+TJvrmkk+kwAAAABJRU5ErkJggg=="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 7.000000 1.000000 L 46.000000 1.000000 L 48.312500 1.500000 L 50.250000 2.750000 L 51.500000 4.687500 L 52.000000 7.000000 L 52.000000 19.000000 L 51.500000 21.312500 L 50.250000 23.250000 L 48.312500 24.500000 L 46.000000 25.000000 L 7.000000 25.000000 L 4.750000 24.562500 L 2.812500 23.250000 L 1.500000 21.312500 L 1.000000 19.000000 L 1.000000 7.000000 L 1.500000 4.687500 L 2.750000 2.750000 L 4.687500 1.500000 L 7.000000 1.000000 z"}
,
"image60":{"x":0,"y":0,"w":787,"h":116,"bOffBottom":0,"i":"images/rr160_operationdeclutter_redops_redspace_header_fa.jpg"}
,
"image77":{"x":790,"y":191,"w":233,"h":136,"bOffBottom":0,"i":"images/rotatephone-300x175.png"}
,
"text75":{"x":790,"y":378,"w":156,"h":62,"txtscale":100,"bOffBottom":0}
,
"image29432":{"x":462,"y":122,"w":314,"h":337,"bOffBottom":0,"i":"images/reggie_character_build_redops_new_product_dev_small.jpg"}
,
"text29430":{"x":9,"y":122,"w":428,"h":249,"txtscale":80,"bOffBottom":0,"bltArr":{numOfItems: 1,0:{"fontId":"Font7", "marginLeft":12, "paddingLeft":13, "bltSrc":"images/PhoneLandscape_text29430CircleBulletFont7.png"}}}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":['images/PhoneLandscape_text29430CircleBulletFont7.png']
},
"480":{
"pageLayer":{"w":480,"h":983,"bgColor":"#ffffff"}
,
"shape74":{"x":-1,"y":954,"w":483.000000,"h":30.000000,"stylemods":[{"sel":"div.shape74Text","decl":" { position:fixed; left:3px; top:3px; width:477px; height:24px;}"},{"sel":"span.shape74Text","decl":" { display:table-cell; position:relative; width:477px; height:24px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAeMAAAAeCAYAAAAfDHZLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABPSURBVHhe7cEBDQAAAMKg909tDwcEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCgBuKGAAEeuTpyAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 482.000000 1.000000 L 482.000000 29.000000 L 1.000000 29.000000 L 1.000000 1.000000 z"}
,
"button65":{"x":738,"y":800,"w":41.000000,"h":23.000000,"stylemods":[{"sel":"div.button65Text","decl":" { position:fixed; left:4px; top:3px; width:33px; height:17px;}"},{"sel":"span.button65Text","decl":" { display:table-cell; position:relative; width:33px; height:17px; vertical-align:middle; text-align:center; line-height:10px; font-size:10px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZLLDQMhDETpJ61sKSkkhVDnEj/Ls/KizSUon4OfhIwHg0cWrSiKolhnjPHY971H6oS2Rfp7MGRrmKl7SMsm4/7x3jJ6EKMhnUxavNnqnBO9wKCGFSl1PWo3akUcr2HvuCEiK2vs1TzpeeIY39Am/VS3TDakprM2kafnU7N49ac/Y1JNs0Zie5/kjOotfs8kkEdjmTz9vYzMEbMp9q/uvAWPyZAw7TAJ1KAF3jyM+YSJHOiOciAviqL4S1p7AnL5ZlPytMImAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZLLDQMhDETpJ61sKSkkhVDnEj/Ls/KizSUon4OfhIwHg0cWrSiKolhnjPHY971H6oS2Rfp7MGRrmKl7SMsm4/7x3jJ6EKMhnUxavNnqnBO9wKCGFSl1PWo3akUcr2HvuCEiK2vs1TzpeeIY39Am/VS3TDakprM2kafnU7N49ac/Y1JNs0Zie5/kjOotfs8kkEdjmTz9vYzMEbMp9q/uvAWPyZAw7TAJ1KAF3jyM+YSJHOiOciAviqL4S1p7AnL5ZlPytMImAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAYCAYAAACMcW/9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVFhH7ZJBDgMhCEW9T6/iUXqQHsRzankEJmimm87YdMFLDPJF/CGWJEmSZD9jjFfvvVmqmFYt/Q8wJWuIsadJl43a/aPfLXhTzJo0GZX4kNU4J2qBQA3LUuqa1VZqHTu+jvRSU0RW1Ni7gaDHyWO+oi36VHcL0ZQ/vGoLcYo6PYlnf3yfUX84aiSy14mueL3E3xoFcnvcjU5/MeIGidEY+093voaGbsoR7TAK1KAZasDM6aSJHPgdz4E8SZIk2Ukpb67bZlMN6NypAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAAXCAYAAACWEGYrAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAADESURBVEhL7ZLLDQMhDETpJ61sKSkkhVDnEj/Ls/KizSUon4OfhIwHg0cWrSiKolhnjPHY971H6oS2Rfp7MGRrmKl7SMsm4/7x3jJ6EKMhnUxavNnqnBO9wKCGFSl1PWo3akUcr2HvuCEiK2vs1TzpeeIY39Am/VS3TDakprM2kafnU7N49ac/Y1JNs0Zie5/kjOotfs8kkEdjmTz9vYzMEbMp9q/uvAWPyZAw7TAJ1KAF3jyM+YSJHOiOciAviqL4S1p7AnL5ZlPytMImAAAAAElFTkSuQmCC"  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 6.000000 1.000000 L 35.000000 1.000000 L 36.937500 1.375000 L 38.562500 2.500000 L 39.625000 4.062500 L 40.000000 6.000000 L 40.000000 17.000000 L 39.625000 18.937500 L 38.562500 20.562500 L 36.937500 21.625000 L 35.000000 22.000000 L 6.000000 22.000000 L 4.125000 21.625000 L 2.500000 20.562500 L 1.375000 18.937500 L 1.000000 17.000000 L 1.000000 6.000000 L 1.375000 4.062500 L 2.500000 2.500000 L 4.062500 1.375000 L 6.000000 1.000000 z"}
,
"image60":{"x":0,"y":0,"w":481,"h":71,"bOffBottom":0,"i":"images/rr160_operationdeclutter_redops_redspace_header_fa.jpg"}
,
"image77":{"x":75,"y":249,"w":338,"h":196,"bOffBottom":0,"i":"images/rotatephone-300x175.png"}
,
"text75":{"x":27,"y":157,"w":423,"h":62,"txtscale":100,"bOffBottom":0}
,
"image29432":{"x":485,"y":158,"w":192,"h":206,"bOffBottom":0,"i":"images/reggie_character_build_redops_new_product_dev_small.jpg"}
,
"text29430":{"x":-267,"y":155,"w":262,"h":298,"txtscale":100,"bOffBottom":0,"bltArr":{numOfItems: 1,0:{"fontId":"Font7", "marginLeft":13, "paddingLeft":10, "bltSrc":"images/text29430CircleBulletFont7.png"}}}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
}
,
"RCDResultResize":function(){}
,"preload":[]
}}
